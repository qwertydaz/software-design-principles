package softwareDesignPrinciples;

public class BankClientRegistrationTransaction {

}
