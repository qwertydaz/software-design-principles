package softwareDesignPrinciples;

public class BankClientProfileCreationTransaction {

}
