package softwareDesignPrinciples;

public class BankClientBookAppointmentTransaction {

}
