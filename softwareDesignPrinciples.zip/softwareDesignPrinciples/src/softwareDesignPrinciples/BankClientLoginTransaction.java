package softwareDesignPrinciples;

public class BankClientLoginTransaction {

}
