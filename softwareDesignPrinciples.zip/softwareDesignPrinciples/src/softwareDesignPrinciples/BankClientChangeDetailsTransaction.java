package softwareDesignPrinciples;

public class BankClientChangeDetailsTransaction {

}
