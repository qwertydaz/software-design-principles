package softwareDesignPrinciples;

import java.util.List;


public interface RegistrationTransaction {

	public BankClient register( List<Person> bankClients );
}