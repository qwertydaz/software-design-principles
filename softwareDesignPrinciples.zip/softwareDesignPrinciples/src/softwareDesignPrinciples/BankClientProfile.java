package softwareDesignPrinciples;

import java.util.Date;


public abstract class BankClientProfile {

	public String address;
	public Date birthDate;

	public BankClientProfile( String address, Date birthDate ) {

		this.address = address;
		this.birthDate = birthDate;
	}

	public void toPrint() {

		System.out.println( "address = " + address );
		System.out.println( "birthDate = " + birthDate );
	}
}