package softwareDesignPrinciples;

public class CandidateBankAccount {

}
