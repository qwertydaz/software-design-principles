package softwareDesignPrinciples;

public class BankClientMoneyTransferTransaction {

}
