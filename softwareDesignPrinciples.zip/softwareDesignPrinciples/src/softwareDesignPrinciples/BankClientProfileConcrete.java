package softwareDesignPrinciples;

public class BankClientProfileConcrete {

}
