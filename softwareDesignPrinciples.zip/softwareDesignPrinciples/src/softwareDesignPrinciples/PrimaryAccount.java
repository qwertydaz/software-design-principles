package softwareDesignPrinciples;

public class PrimaryAccount {

}
