package softwareDesignPrinciples;

public class SavingsAccount {

}
