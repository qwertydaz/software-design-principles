module softwareDesignPrinciples {
}