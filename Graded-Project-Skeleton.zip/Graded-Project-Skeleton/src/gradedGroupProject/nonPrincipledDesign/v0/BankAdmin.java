package gradedGroupProject.nonPrincipledDesign.v0;

import java.util.List;


public class BankAdmin {

	public String name = "Y";

	public List<BankClient> bankClientsToVerify;
	public List<Integer> accountNumbersToVerify;


	public static void main( String[] args ) {

		//TODO


		//TODO

			System.out.println( "1. Verify the opening" );
			System.out.println( "2. Do not verify the opening" );

			//verify( accountNumber, true ); //we assume that we are answering to the client with this call
	}
}
