package softwareDesignPrinciples;

public class PrimaryAccount extends BankAccount {
	
	public PrimaryAccount() {
		super();
	}
	
	public PrimaryAccount( int accountNumber) {
		super(accountNumber);
	}
}
