package softwareDesignPrinciples;

public class StdInputRead {

}
