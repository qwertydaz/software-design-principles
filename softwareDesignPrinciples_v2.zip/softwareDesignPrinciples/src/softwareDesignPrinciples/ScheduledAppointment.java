package softwareDesignPrinciples;

public class ScheduledAppointment {

}
