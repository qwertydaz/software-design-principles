package softwareDesignPrinciples;

public class BankEmployeeVerifyAppointmentsTransaction {

}
