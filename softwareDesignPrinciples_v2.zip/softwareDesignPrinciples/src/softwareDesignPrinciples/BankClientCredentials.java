package softwareDesignPrinciples;

public class BankClientCredentials {

}
