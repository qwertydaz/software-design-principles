package softwareDesignPrinciples;

public class BankAccountCreationTransaction {
	
	public void create(boolean savings) {
		BankAccount account;
		if(savings) {
			account = new SavingsAccount();
		} else {
			account = new PrimaryAccount();
		}
		
		CandidateBankAccount.createCandidate(account);
		
	}

}
