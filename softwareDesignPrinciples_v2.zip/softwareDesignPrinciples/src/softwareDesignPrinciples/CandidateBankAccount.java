package softwareDesignPrinciples;

public class CandidateBankAccount {
	
	public void createCandidate(BankAccount account){
		BankAdminVerifyBankAccounts.verifyAccount(account);
	}
}
