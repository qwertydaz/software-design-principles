package softwareDesignPrinciples;

public class BankAdminVerifyBankAccounts {
	
	public boolean verifyAccount() {
		return true;
	}
}
