package softwareDesignPrinciples;

import java.util.Date;

public class BankClientProfileConcrete extends BankClientProfile {
	
	public BankClientProfileConcrete(String name, String address, Date birthDate) {
		
		super(name, address, birthDate);
	}
	
	
}
