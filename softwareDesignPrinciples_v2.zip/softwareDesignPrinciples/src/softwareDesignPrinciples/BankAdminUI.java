package softwareDesignPrinciples;

public class BankAdminUI {

}
