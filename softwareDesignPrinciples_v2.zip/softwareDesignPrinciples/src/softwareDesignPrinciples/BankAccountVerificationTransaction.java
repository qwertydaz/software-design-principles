package softwareDesignPrinciples;

public class BankAccountVerificationTransaction {
	
	
}
