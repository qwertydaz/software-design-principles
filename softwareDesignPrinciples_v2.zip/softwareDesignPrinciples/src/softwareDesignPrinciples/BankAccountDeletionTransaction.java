package softwareDesignPrinciples;

public class BankAccountDeletionTransaction {

}
