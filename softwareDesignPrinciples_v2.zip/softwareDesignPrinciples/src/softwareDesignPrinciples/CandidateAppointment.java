package softwareDesignPrinciples;

public class CandidateAppointment {

}
