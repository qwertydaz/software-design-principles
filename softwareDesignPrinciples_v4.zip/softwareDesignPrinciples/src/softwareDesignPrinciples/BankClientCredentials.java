package softwareDesignPrinciples;

public class BankClientCredentials {
	
	private String username;
	private String password;
	private BankClientProfileConcrete profile;
	
	public BankClientCredentials(String username,String password, BankClientProfileConcrete profile) {
		this.username = username;
		this.password = password;
		this.profile = profile;
	}
	
	public String getUsername() {
		return username;
	}
	
	public String getPassword() {
		return password;
	}
	
	public BankClientProfileConcrete getProfile() {
		return profile;
	}
	
	public void setUsername(String username) {
		while (username.charAt(0) == '$') {
			StdInputRead.read("Invalid username. Provide new username:\n>\n");
			username = StdInputRead.stringInput();
		}
		this.username = username;
	}
	
	public void setPassword(String password) {
		while (username.charAt(-1) == '.') {
			StdInputRead.read("Invalid password. Provide new password:\n>\n");
			password = StdInputRead.stringInput();
		}
		this.password = password;
	}
	
	
}
