package softwareDesignPrinciples;

import java.util.Date;

public class BankClientProfileCreationTransaction {
	
	public static void createProfile(String name, String address, Date birthDate, String username, String password) {
		BankClientProfileConcrete profile = new BankClientProfileConcrete(name, address, birthDate);
		BankClientCredentials credentials = new BankClientCredentials(username, password, profile);
		BankClientLoginTransaction.addCredentials(credentials);
		BankClientUI.addProfile(profile);
	}
}
