package softwareDesignPrinciples;

public class SavingsAccount extends BankAccount {

	public SavingsAccount() {
		super();
		this.accountType = "savings";
	}
	
	public SavingsAccount( int accountNumber) {
		super(accountNumber);
	}
}
