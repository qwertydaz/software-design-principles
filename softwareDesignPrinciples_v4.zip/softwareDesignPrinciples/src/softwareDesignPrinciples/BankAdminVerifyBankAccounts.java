package softwareDesignPrinciples;

import java.util.ArrayList;

public class BankAdminVerifyBankAccounts {
	
	public static ArrayList<ArrayList<Object>> ProfilesToVerify = new ArrayList<ArrayList<Object>>();
	
	public static void verifyAccount() {
		for(ArrayList<Object> details: ProfilesToVerify) {
			BankClientProfileConcrete profileToVerify = (BankClientProfileConcrete) details.get(0);
			BankAccount accountToVerify = null;
			boolean savings = (boolean) details.get(2);
			String accountType;
			String username = null;
			String password = null;
			if(savings) {
				accountType = "savings";
				accountToVerify = (SavingsAccount) details.get(1);
			} else {
				accountType = "primary";
				accountToVerify = (PrimaryAccount) details.get(1);
			}
			
			for(BankClientCredentials credentials: BankClientDictionarySingleton.Credentials) {
				if (credentials.getProfile() == profileToVerify) {
					username = credentials.getUsername();
					password = credentials.getPassword();
				}
			}
			
			StdInputRead.read("Account number = " + accountToVerify.accountNumber + ", accountType = " + accountType + "\n"
					+ "clientID = " + profileToVerify.clientNumber + "\n"
					+ "name = " + profileToVerify.name + "\n"
					+ "username = " + username + "\n"
					+ "password = " + password + "\n"
					+ "address = " + profileToVerify.address + "\n"
					+ "birthDate = " + profileToVerify.birthDate + "\n");
		}
		
		for(ArrayList<Object> details: ProfilesToVerify) {
			BankClientProfileConcrete profileToVerify = (BankClientProfileConcrete) details.get(0);
			BankAccount accountToVerify = null;
			boolean savings = (boolean) details.get(2);
			if(savings) {
				accountToVerify = (SavingsAccount) details.get(1);
			} else {
				accountToVerify = (PrimaryAccount) details.get(1);
			}
			StdInputRead.read("Account Number = " + accountToVerify.accountNumber + "\n"
					+ "1. Verify the opening\n"
					+ "2. Do not verify the opening\n\n"
					+ "Provide choice:\n>\n");
			Integer choice = StdInputRead.integerInput();
			if(choice==1) {
				BankAccountVerificationTransaction.accountVerification(profileToVerify, accountToVerify, savings);
			}
		}
	}
	
	public static void addAccountToVerify(BankClientProfileConcrete profile, boolean savings, BankAccount account) {
		ArrayList<Object> details = new ArrayList<Object>();
		details.add(profile);
		details.add(account);
		details.add(savings);
		ProfilesToVerify.add(details);  
		BankAccountVerificationTransaction.accountVerification(profile, account, savings);
	}
}
