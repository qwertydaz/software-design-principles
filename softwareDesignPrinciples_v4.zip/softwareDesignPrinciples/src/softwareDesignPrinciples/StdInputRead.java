package softwareDesignPrinciples;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class StdInputRead {
	
	static Scanner input = new Scanner(System.in);
	
	public static String stringInput() {
		String result = input.nextLine();
		input.nextLine();
		return result;
	}
	
	public static Integer integerInput() {
		Integer result = input.nextInt();
		return result;
	}
	
	public static Double doubleInput() {
		Double result = input.nextDouble();
		return result;
	}
	
	public static Date dateInput() {
		String result = input.nextLine();
		input.nextLine();
		Date date = null;
		try {
			date = new SimpleDateFormat("dd/MM/yyyy").parse(result);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static boolean booleanInput() {
		boolean result = input.nextBoolean();
		return result;
	}
	
	public static void read(String text) {
		System.out.print(text);
	}
	
	public static void read(Integer number) {
		System.out.print(number);
	}
	
	public static void read(Double number) {
		System.out.print(number);
	}
	
	public static void read(Date date) {
		System.out.print(date);
	}
	
	public static void read(boolean bool) {
		System.out.print(bool);
	}
}
