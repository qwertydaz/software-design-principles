package softwareDesignPrinciples;

public class BankClientLoginTransaction {

	public static BankClientProfileConcrete login(String username, String password) {
		BankClientProfileConcrete profile = null;
		for(BankClientCredentials cred: BankClientDictionarySingleton.Credentials) {
			if(cred.getUsername().equals(username) && cred.getPassword().equals(password)) {
				profile = cred.getProfile();
			}
		}
		return profile;
	}
	
	public static void addCredentials(BankClientCredentials credentials) {
		BankClientDictionarySingleton.Credentials.add(credentials);
	}
}
