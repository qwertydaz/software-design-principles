package softwareDesignPrinciples;

public class CandidateBankAccount {
	
	public static void createCandidate(BankClientProfileConcrete profile, boolean savings, BankAccount account){
		BankAdminVerifyBankAccounts.addAccountToVerify(profile, savings, account);
	}
}
