package softwareDesignPrinciples;

import java.util.Date;

public class BankClientUI {
	
	public static void main(String args[]) {
		boot();
	}
	
	public static void addProfile(BankClientProfileConcrete profile) {
		BankClientDictionarySingleton.addBankClient(profile);
		boolean savings = false;
		StdInputRead.read("Provide account type (primary, savings):\n>\n");
		String accountType = StdInputRead.stringInput();
		if(accountType == "savings") {
			savings = true;
		}
		BankAccountCreationTransaction.create(profile, savings);
		StdInputRead.read("\n0. NO extra account\n"
				+ "1. Extra account\n\n"
				+ "Provide choice:\n>\n");
		Integer choice = StdInputRead.integerInput();
		while (choice != 0) {
			StdInputRead.read("Provide account type (primary, savings):\n>\n");
			accountType = StdInputRead.stringInput();
			if(accountType == "savings") {
				savings = true;
			}
			BankAccountCreationTransaction.create(profile, savings);
		}
		
		BankClientDictionarySingleton.printBankClients();
	}
	
	public static void boot() {
		StdInputRead.read("0: Exit\n"
				+ "1: Register\n"
				+ "4: Login\n\n"
				+ "Provide choice:\n>\n");
		Integer choice = StdInputRead.integerInput();
		if(choice==4) {
			StdInputRead.read("Provide username:\n>\n");
			String username = StdInputRead.stringInput();
			StdInputRead.read("Provide password:\n>\n");
			String password = StdInputRead.stringInput();
			
			BankClientProfileConcrete profile = BankClientLoginTransaction.login(username, password);
			if (profile == null) {
				StdInputRead.read("Bank client credentials were not found.\n");
			} else {
				BankClientDictionarySingleton.printBankClients();
			
				StdInputRead.read("Provide account number:\n>\n");
				int accountNum = StdInputRead.integerInput();
			
				for(BankAccount account: profile.BankAccounts) {
					if (account.accountNumber == accountNum) {
						if(account.accountType == "savings") {
							StdInputRead.read("accountType: savings\naccount Number = " + accountNum +", accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance );
						} else {
							StdInputRead.read("accountType: primary\naccount Number = " + accountNum + ", accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance);
						}
					}
				}
				BankClientDictionarySingleton.printBankClients();
				profile(profile);
			}
		} else if(choice == 1) {
			StdInputRead.read("Provide username:\n>\n");
			String username = StdInputRead.stringInput();
			StdInputRead.read("Provide password:\n>\n");
			String password = StdInputRead.stringInput();
			StdInputRead.read("Provide name:\n>\n");
			String name = StdInputRead.stringInput();
			StdInputRead.read("Provide address:\n>\n");
			String address = StdInputRead.stringInput();
			StdInputRead.read("Provide birthDate:\n>\n");
			Date birthDate = StdInputRead.dateInput();
			
			BankClientRegistrationTransaction.registerProfile(name, address, birthDate, username, password);
			boot();
		} else if(choice == 0) {
			return;
		} else {
			StdInputRead.read("Invalid choice\n");
			boot();
		}
	}
	
	public static void profile(BankClientProfileConcrete profile) {
		 StdInputRead.read("0. Exit\n"
		 		+ "5. Change Bank Account Details\n"
		 		+ "6. Delete Bank Account\n"
		 		+ "7. Money Transfer\n"
		 		+ "8. Book Appointment\n\n"
		 		+ "Provide choice:\n>\n");
		 Integer choice = StdInputRead.integerInput();
		 if (choice == 0) {
			 boot();
		 } else if(choice == 5) {
			 StdInputRead.read("Provide new username:\n>\n");
			 String username = StdInputRead.stringInput();
			 StdInputRead.read("Provide new password:\n>\n");
			 String password = StdInputRead.stringInput();
			 StdInputRead.read("Provide new name:\n>\n");
			 String name = StdInputRead.stringInput();
			 StdInputRead.read("Provide new address:\n>\n");
			 String address = StdInputRead.stringInput();
			 StdInputRead.read("Provide new birthDate:\n>\n");
			 Date birthDate = StdInputRead.dateInput();
			 
			 BankClientChangeDetailsTransaction.changeDetails(profile, username, password, name, address, birthDate);
			 BankClientDictionarySingleton.printBankClients();
		 } else if(choice == 6) {
			 BankAccountDeletionTransaction.deleteAccount(profile);
			 BankClientDictionarySingleton.printBankClients();
		 } else if(choice == 7) {
			 BankClientMoneyTransferTransaction.transfer(profile);
			 BankClientDictionarySingleton.printBankClients();
		 } else if(choice == 8) {
			 BankClientBookAppointmentTransaction.createCandidateAppointment(profile);
			 BankClientDictionarySingleton.printBankClients();
		 }
	}
}
