package softwareDesignPrinciples;

public class BankAccountVerificationTransaction {
	
	public static void accountVerification(BankClientProfileConcrete profile, BankAccount account, boolean savings) {
		profile.addAccount(account, savings);
		StdInputRead.read("Account number " + account.accountNumber + ", verified: true");
	}
}
