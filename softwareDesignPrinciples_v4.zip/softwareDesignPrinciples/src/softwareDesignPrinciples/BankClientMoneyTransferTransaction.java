package softwareDesignPrinciples;

public class BankClientMoneyTransferTransaction {

	public static void transfer(BankClientProfileConcrete profile) {
		for(BankAccount account: profile.BankAccounts) {
			if(account.accountType == "savings") {
				StdInputRead.read("accountType: savings\naccount Number = " + account.accountNumber +", accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance );
			} else {
				StdInputRead.read("accountType: primary\naccount Number = " + account.accountNumber + ", accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance);
			}
		}
		
		StdInputRead.read("Provide from account number:\n>\n");
		int fromNum = StdInputRead.integerInput();
		BankAccount fromAccount = null;
		StdInputRead.read("Provide to account number:\n>\n");
		int toNum = StdInputRead.integerInput();
		BankAccount toAccount = null;
		
		for(BankAccount account: profile.BankAccounts) {
			if(account.accountNumber == fromNum) {
				fromAccount = account;
			} else if(account.accountNumber == toNum) {
				toAccount = account;
			}
		}
		
		StdInputRead.read("Provide amount:\n>\n");
		double amount = StdInputRead.doubleInput();
		if(amount < fromAccount.accountBalance) {
			fromAccount.accountBalance -= amount;
			toAccount.accountBalance += amount;
		} else {
			StdInputRead.read("Not enough amount in the source account\n");
		}
	}
}
