package softwareDesignPrinciples;

public class PrimaryAccount extends BankAccount {
	
	public PrimaryAccount() {
		super();
		this.accountType = "primary";
	}
	
	public PrimaryAccount( int accountNumber) {
		super(accountNumber);
	}
}
