package softwareDesignPrinciples;

public class BankAccountCreationTransaction {
	
	public static void create(BankClientProfileConcrete profile, boolean savings) {	
		BankAccount account = null;
		if (savings) {
			account = new SavingsAccount();
		} else {
			account = new PrimaryAccount();
		}
		account.setAccountBalance(100);
		CandidateBankAccount.createCandidate(profile, savings, account);
		
	}

}
