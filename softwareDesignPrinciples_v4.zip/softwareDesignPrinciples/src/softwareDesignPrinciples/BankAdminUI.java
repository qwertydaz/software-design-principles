package softwareDesignPrinciples;

public class BankAdminUI {

	public static void main(String args[]) {
		boot();
	}
	
	public static void boot() {
		BankAdminVerifyBankAccounts.verifyAccount();
	}
	
}
