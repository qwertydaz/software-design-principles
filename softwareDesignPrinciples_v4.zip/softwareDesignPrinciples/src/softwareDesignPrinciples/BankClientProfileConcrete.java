package softwareDesignPrinciples;

import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;

public class BankClientProfileConcrete extends BankClientProfile {
	
	ArrayList<BankAccount> BankAccounts = new ArrayList<BankAccount>();
	
	public static final AtomicInteger clientCount = new AtomicInteger( 0 );

	public int clientNumber;
	
	public BankClientProfileConcrete(String name, String address, Date birthDate) {
		super(name, address, birthDate);
		
		this.clientNumber = clientCount.incrementAndGet();
	}
	
	public void addAccount(BankAccount account, boolean savings) {
		if(savings) {
			SavingsAccount savingsTemp = (SavingsAccount) account;
			BankAccounts.add(savingsTemp);
		} else {
			PrimaryAccount primaryTemp = (PrimaryAccount) account;
			BankAccounts.add(primaryTemp);
		}
	}
	
}
