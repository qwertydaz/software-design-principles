package softwareDesignPrinciples;

public class BankAccountDeletionTransaction {
	
	public static void deleteAccount(BankClientProfileConcrete profile) {
		for(BankAccount account: profile.BankAccounts) {
			if(account.accountType == "savings") {
				StdInputRead.read("accountType: savings\naccount Number = " + account.accountNumber +", accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance );
			} else {
				StdInputRead.read("accountType: primary\naccount Number = " + account.accountNumber + ", accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance);
			}
		}
		StdInputRead.read("Provide account number:\n>\n");
		int accountNum = StdInputRead.integerInput();
		
		for(BankAccount account: profile.BankAccounts) {
			if(account.accountNumber == accountNum) {
				account = null;
			}
		}
	}
}
