package softwareDesignPrinciples;

import java.util.Date;

public class BankClientChangeDetailsTransaction {
	
	public static void changeDetails(BankClientProfileConcrete profile, String username, String password, String name, String address, Date birthDate) {
		for(BankClientCredentials credentials: BankClientDictionarySingleton.Credentials) {
			if (credentials.getProfile() == profile) {
				credentials.setUsername(username);
				credentials.setPassword(password);
			}
		}
		profile.name = name;
		profile.address = address;
		profile.birthDate = birthDate;
	}
}
