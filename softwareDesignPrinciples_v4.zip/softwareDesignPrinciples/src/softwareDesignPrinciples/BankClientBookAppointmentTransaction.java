package softwareDesignPrinciples;

import java.util.Date;

public class BankClientBookAppointmentTransaction {
	
	public static void createCandidateAppointment(BankClientProfileConcrete profile) {
		StdInputRead.read("Provide appointment date:\n>\n");
		Date date = StdInputRead.dateInput();
		CandidateAppointment appointment = new CandidateAppointment(date, profile);
		boolean check = ScheduledAppointment.checkAvailability(appointment);
		if(check == true) {
			BankEmployeeVerifyAppointmentsTransaction.addCandidateAppointment(appointment);
		}
	}
}
