package softwareDesignPrinciples;

import java.util.ArrayList;

public class BankClientDictionarySingleton {
	
	public static ArrayList<BankClientProfileConcrete> Profiles = new ArrayList<BankClientProfileConcrete>();
	public static ArrayList<BankClientCredentials> Credentials = new ArrayList<BankClientCredentials>();
	
	public static void addBankClient(BankClientProfileConcrete client) {
		Profiles.add(client);
	}
	
	public static void printBankClients() {
		for (BankClientCredentials credentials: Credentials) {
			StdInputRead.read("username = " + credentials.getUsername() + "\n"
					+ "password = " + credentials.getPassword() + "\n"
					+ "client number = " + credentials.getProfile().clientNumber + "\n"
					+ "name = " + credentials.getProfile().name + "\n"
					+ "address = " + credentials.getProfile().address + "\n"
					+ "birthDate = " + credentials.getProfile().birthDate + "\n");
			for(BankAccount account: credentials.getProfile().BankAccounts) {
				if(account.accountType == "savings") {
					StdInputRead.read("accountType: savings, accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance );
				} else {
					StdInputRead.read("accountType: primary, accountVerified = " + account.accountVerified + ", accountBalance = " + account.accountBalance);
				}
			}
		}
	}
	
	public static int searchBankClient(String username, String password) {
		int result = -1;
		for(BankClientCredentials credentials: Credentials) {
			if(credentials.getUsername() == username && credentials.getPassword() == password) {
				result =  credentials.getProfile().clientNumber;
			}
		}
		return result;
	}
	
	public int size() {
		return Profiles.size();
	}
	
	public BankClientProfileConcrete get(int position) {
		return Profiles.get(position);
	}
	
	public void delete(int ID) {
		for(BankClientProfileConcrete profile: Profiles) {
			if(profile.clientNumber == ID) {
				profile = null;
			}
		}
	}
}
