package softwareDesignPrinciples;

import java.util.List;

public interface RegistrationTransaction {

	public BankAccount register( List<Person> bankClients );
}