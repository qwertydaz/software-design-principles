   package softwareDesignPrinciples;

import java.util.ArrayList;

public class BankEmployeeVerifyAppointmentsTransaction {
	
	public static ArrayList<CandidateAppointment> CandidateAppointments = new ArrayList<CandidateAppointment>();
	
	public static void verifyAppointment(String name) {
		for(CandidateAppointment candidate: CandidateAppointments) {
			BankClientProfileConcrete client = candidate.getClient();
			String username = null;
			String password = null;
			for(BankClientCredentials credentials: BankClientDictionarySingleton.Credentials) {
				if (credentials.getProfile() == client) {
					username = credentials.getUsername();
					password = credentials.getPassword();
				}
			}
			
			StdInputRead.read("Appointment date: " + candidate.getAppointmentDate() + "\n"
					+ "clientID = " + client.clientNumber + "\n"
					+ "name = " + client.name + "\n"
					+ "username = " + username + "\n"
					+ "password = " + password + "\n");
		}
		
		for(CandidateAppointment candidate: CandidateAppointments) {
			StdInputRead.read("Candidate date = " + candidate.getAppointmentDate() + " with client = " + candidate.getClient().name + "\n"
					+ "1. Book it\n"
					+ "2. Do not book it\n\n"
					+ "Provide choice:\n>\n");
			Integer choice = StdInputRead.integerInput();
			if(choice==1) {
				StdInputRead.read("Appointment date " + candidate.getAppointmentDate() + ", scheduled: true\n");
				candidate.setEmployee(name);
				ScheduledAppointment.addAppointment(candidate);
			}
			StdInputRead.read("Appointment date " + candidate.getAppointmentDate() + ", scheduled: false\n");
			
		}
	}
	
	public static void addCandidateAppointment(CandidateAppointment appointment) {
		CandidateAppointments.add(appointment);
		appointment.setEmployee("System");
		ScheduledAppointment.addAppointment(appointment);
		StdInputRead.read("Appointment date " + appointment.getAppointmentDate() + ", scheduled: true\n");
	}
}
