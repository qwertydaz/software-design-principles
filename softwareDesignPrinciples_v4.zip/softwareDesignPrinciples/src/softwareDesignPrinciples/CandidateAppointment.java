package softwareDesignPrinciples;

import java.util.Date;

public class CandidateAppointment {
	
	private Date appointmentDate;
	private String employeeName;
	private BankClientProfileConcrete client;
	
	public CandidateAppointment(Date date, BankClientProfileConcrete client) {
		if (date.before(new Date()) == false) {
			this.appointmentDate = date;
		} else {
			this.appointmentDate = new Date();
		}
		this.client = client;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public BankClientProfileConcrete getClient() {
		return client;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployee(String employeeName) {
		this.employeeName = employeeName;
	}
	
}
