package softwareDesignPrinciples;

import java.util.ArrayList;

public class BankEmployeeVerifyAppointmentsTransaction {
	
	public static ArrayList<CandidateAppointment> CandidateAppointments = new ArrayList<CandidateAppointment>();
	
	public static void verifyAppointment(String name) {
		for(CandidateAppointment candidate: CandidateAppointments) {
			StdInputRead.read("1: Verify\n"
					+ "2: Deny\n");
			Integer choice = StdInputRead.integerInput();
			if(choice==1) {
				candidate.setEmployee(name);
				ScheduledAppointment.addAppointment(candidate);
			}
			
		}
	}
	
	public static void addCandidateAppointment(CandidateAppointment appointment) {
		CandidateAppointments.add(appointment);
		appointment.setEmployee("System");
		ScheduledAppointment.addAppointment(appointment);
	}
}
