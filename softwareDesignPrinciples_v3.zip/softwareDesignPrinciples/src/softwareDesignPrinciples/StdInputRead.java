package softwareDesignPrinciples;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class StdInputRead {
	
	public static String stringInput() {
		Scanner input = new Scanner(System.in);
		String result = input.nextLine();
		input.nextLine();
		input.close();
		return result;
	}
	
	public static Integer integerInput() {
		Scanner input = new Scanner(System.in);
		Integer result = input.nextInt();
		input.nextLine();
		input.close();
		return result;
	}
	
	public static Double doubleInput() {
		Scanner input = new Scanner(System.in);
		Double result = input.nextDouble();
		input.nextLine();
		input.close();
		return result;
	}
	
	public static Date dateInput() {
		Scanner input = new Scanner(System.in);
		String result = input.nextLine();
		input.nextLine();
		input.close();
		Date date = null;
		try {
			date = new SimpleDateFormat("dd/MM/yyyy").parse(result);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
	
	public static boolean booleanInput() {
		Scanner input = new Scanner(System.in);
		boolean result = input.nextBoolean();
		input.nextLine();
		input.close();
		return result;
	}
	
	public static void read(String text) {
		System.out.print(text);
	}
	
	public static void read(Integer number) {
		System.out.print(number);
	}
	
	public static void read(Double number) {
		System.out.print(number);
	}
	
	public static void read(Date date) {
		System.out.print(date);
	}
	
	public static void read(boolean bool) {
		System.out.print(bool);
	}
}
