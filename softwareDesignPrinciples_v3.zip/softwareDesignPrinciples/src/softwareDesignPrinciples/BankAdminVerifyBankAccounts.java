package softwareDesignPrinciples;

import java.util.ArrayList;

public class BankAdminVerifyBankAccounts {
	
	public static ArrayList<BankClientProfileConcrete> ProfilesToVerify = new ArrayList<BankClientProfileConcrete>();
	
	public static void verifyAccount() {
		for(BankClientProfileConcrete profileToVerify: ProfilesToVerify) {
			StdInputRead.read("1: Verify\n"
					+ "2: Deny\n");
			Integer choice = StdInputRead.integerInput();
			if(choice==1) {
				BankAccountVerificationTransaction.accountVerification(profileToVerify);
			}
		}
	}
	
	public static void addAccountToVerify(BankClientProfileConcrete profile) {
		ProfilesToVerify.add(profile);
		BankAccountVerificationTransaction.accountVerification(profile);
	}
}
