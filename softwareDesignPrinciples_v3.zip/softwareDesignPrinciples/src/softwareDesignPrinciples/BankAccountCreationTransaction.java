package softwareDesignPrinciples;

public class BankAccountCreationTransaction {
	
	public static void create(BankClientProfileConcrete profile) {	
		CandidateBankAccount.createCandidate(profile);
		
	}

}
