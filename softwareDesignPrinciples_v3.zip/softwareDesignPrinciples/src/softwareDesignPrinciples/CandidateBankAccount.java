package softwareDesignPrinciples;

public class CandidateBankAccount {
	
	public static void createCandidate(BankClientProfileConcrete profile){
		BankAdminVerifyBankAccounts.addAccountToVerify(profile);
	}
}
