package softwareDesignPrinciples;

import java.util.Date;
import java.util.List;

public class BankClientRegistrationTransaction implements RegistrationTransaction{
	
	@Override
	public BankAccount register(List<Person> bankClients) {
		return null;
	}
	
	public static void registerProfile(String name, String address, Date birthDate) {
		BankClientProfileCreationTransaction.createProfile(name, address, birthDate);
		
	}
	
}
