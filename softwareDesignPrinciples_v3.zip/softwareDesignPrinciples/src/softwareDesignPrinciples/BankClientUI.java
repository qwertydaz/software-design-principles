package softwareDesignPrinciples;

import java.util.ArrayList;
import java.util.Date;

public class BankClientUI {
	
	public static ArrayList<BankClientProfileConcrete> Profiles = new ArrayList<BankClientProfileConcrete>();
	
	public static void main(String[] args) {
		boot();
	}
	
	public static void addProfile(BankClientProfileConcrete profile) {
		Profiles.add(profile);
		BankAccountCreationTransaction.create(profile);
	}
	
	public static void boot() {
		StdInputRead.read("0: Exit\n"
				+ "1: Register\n"
				+ "4: Login\n");
		Integer choice = StdInputRead.integerInput();
		if(choice==4) {
			String username = StdInputRead.stringInput();
			String password = StdInputRead.stringInput();
			BankClientProfileConcrete profile = BankClientLoginTransaction.login(username, password);
			profile(profile);
		} else if(choice == 1) {
			String name = StdInputRead.stringInput();
			String address = StdInputRead.stringInput();
			Date birthDate = StdInputRead.dateInput();
			BankClientRegistrationTransaction.registerProfile(name, address, birthDate);
		} else if(choice == 0) {
			return;
		} else {
			StdInputRead.read("Invalid choice\n");
			boot();
		}
	}
	
	public static void profile(BankClientProfileConcrete profile) {
		 StdInputRead.read("0: Exit\n"
		 		+ "5: Change Bank Account Details\n"
		 		+ "6: Delete Bank Account\n"
		 		+ "7: Money Transfer\n"
		 		+ "8: Book Appointment\n");
		 Integer choice = StdInputRead.integerInput();
		 if (choice == 0) {
			 boot();
		 } else if(choice == 5) {
			 String name = StdInputRead.stringInput();
			 String address = StdInputRead.stringInput();
			 Date birthDate = StdInputRead.dateInput();
			 BankClientChangeDetailsTransaction.changeDetails(profile, name, address, birthDate);
		 } else if(choice == 6) {
			 BankAccountDeletionTransaction.deleteAccount(profile);
		 } else if(choice == 7) {
			 StdInputRead.read("0: Savings to Primary\n"
			 		+ "1: Primary to Savings\n");
			 Integer transferChoice = StdInputRead.integerInput();
			 Double amount = StdInputRead.doubleInput();
			 if (transferChoice == 0) {
				 BankClientMoneyTransferTransaction.transfer(profile, amount, true);
			 } else if(transferChoice == 1) {
				 BankClientMoneyTransferTransaction.transfer(profile, amount, false);
			 }
		 } else if(choice == 8) {
			 Date date = StdInputRead.dateInput();
			 String time = StdInputRead.stringInput();
			 BankClientBookAppointmentTransaction.createCandidateAppointment(date, time);
		 }
		 
	}
	

}
