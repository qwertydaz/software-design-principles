package softwareDesignPrinciples;

import java.util.ArrayList;

public class ScheduledAppointment {
	
	static ArrayList<CandidateAppointment> ScheduledAppointments = new ArrayList<CandidateAppointment>();
	
	public static boolean checkAvailability(CandidateAppointment appointment) {
		for (CandidateAppointment scheduled: ScheduledAppointments) {
			if(appointment == scheduled) {
				return false;
			}
		}
		return true;
	}
	
	public static void addAppointment(CandidateAppointment appointment) {
		ScheduledAppointments.add(appointment);
	}
}
