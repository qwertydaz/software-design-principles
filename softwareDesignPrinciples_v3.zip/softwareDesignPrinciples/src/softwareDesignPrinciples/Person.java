package softwareDesignPrinciples;



public abstract class Person {

	public String name;

	public Person( String name ) {

		this.name = name;
	}

	public void toPrint() {

		System.out.println( "name = " + name );
	}
}