package softwareDesignPrinciples;

import java.util.Date;

public class BankClientProfileConcrete extends BankClientProfile {
	
	private SavingsAccount savingsAccount;
	private PrimaryAccount primaryAccount;
	
	public BankClientProfileConcrete(String name, String address, Date birthDate) {
		
		super(name, address, birthDate);
	}
	
	public SavingsAccount getSavingsAccount() {
		return savingsAccount;
	}
	
	public double getSavingsAmount() {
		return savingsAccount.accountBalance;
	}
	
	public PrimaryAccount getPrimaryAccount() {
		return primaryAccount;
	}
	
	public double getPrimaryAmount() {
		return primaryAccount.accountBalance;
	}
	
	public void setSavingsAccount(SavingsAccount account) {
		this.savingsAccount = account;
	}
	
	public void setSavingsAmount(double amount) {
		this.savingsAccount.setAccountBalance(amount);
	}
	
	public void setPrimaryAccount(PrimaryAccount account) {
		this.primaryAccount = account;
	}
	
	public void setPrimaryAmount(double amount) {
		this.primaryAccount.setAccountBalance(amount);
	}
	
}
