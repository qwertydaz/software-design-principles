package softwareDesignPrinciples;
import java.util.concurrent.atomic.AtomicInteger;


public abstract class BankAccount {

	public static final AtomicInteger accountCount = new AtomicInteger( 0 );

	public int accountNumber;
	public boolean accountVerified;
	public double accountBalance;

	public BankAccount() {

		this.accountNumber = accountCount.incrementAndGet();

		accountVerified = false;
		accountBalance = 100.0;
	}

	public BankAccount( int accountNumber ) {

		this.accountNumber = accountNumber;

		accountVerified = false;
		accountBalance = 100.0;
	}

	public void setAccountBalance( double accountBalance ) {

		this.accountBalance = accountBalance;
	}

	public void print() {

		System.out.println( "\naccountNumber = " + accountNumber + ", accountVerified = " + accountVerified + ", accountBalance = " + accountBalance );
	}
}

