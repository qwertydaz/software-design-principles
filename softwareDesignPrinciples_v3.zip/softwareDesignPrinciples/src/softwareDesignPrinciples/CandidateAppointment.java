package softwareDesignPrinciples;

import java.util.Date;

public class CandidateAppointment {
	
	private Date appointmentDate;
	private String appointmentTime;
	private String employeeName;
	
	public CandidateAppointment(Date date, String time) {
		this.appointmentDate = date;
		this.appointmentTime = time;
	}
	
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	
	public String getAppointmentTime() {
		return appointmentTime;
	}
	
	public String getEmployeeName() {
		return employeeName;
	}
	
	public void setEmployee(String employeeName) {
		this.employeeName = employeeName;
	}
	
}
