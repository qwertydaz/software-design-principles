package softwareDesignPrinciples;

import java.util.Date;

public class BankClientProfileCreationTransaction {
	
	public static void createProfile(String name, String address, Date birthDate) {
		BankClientProfileConcrete profile = new BankClientProfileConcrete(name, address, birthDate);
		BankClientUI.addProfile(profile);
	}
}
