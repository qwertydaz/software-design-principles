package softwareDesignPrinciples;

import java.util.Date;

public class BankClientChangeDetailsTransaction {
	
	public static void changeDetails(BankClientProfileConcrete bcpc, String name, String address, Date birthDate) {
		bcpc.name = name;
		bcpc.address = address;
		bcpc.birthDate = birthDate;
	}
}
