package softwareDesignPrinciples;

public class BankClientMoneyTransferTransaction {

	public static void transfer(BankClientProfileConcrete profile, double amount, boolean toPrimary) {
		double savingsAmount = profile.getSavingsAmount();
		double primaryAmount = profile.getPrimaryAmount();
		
		if(toPrimary) {
			profile.setSavingsAmount(savingsAmount-amount);
			profile.setPrimaryAmount(primaryAmount+amount);
		} else {
			profile.setPrimaryAmount(primaryAmount-amount);
			profile.setSavingsAmount(savingsAmount+amount);
		}
	}
}
