package softwareDesignPrinciples;

public class BankAccountVerificationTransaction {
	
	public static void accountVerification(BankClientProfileConcrete profile) {
		SavingsAccount savingsAccount = new SavingsAccount();
		PrimaryAccount primaryAccount = new PrimaryAccount();
		
		savingsAccount.accountVerified = true;
		primaryAccount.accountVerified = true;
		
		profile.setSavingsAccount(savingsAccount);
		profile.setPrimaryAccount(primaryAccount);
	}
}
