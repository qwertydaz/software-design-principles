package softwareDesignPrinciples;

public class BankEmployeeUI {

	public static void main(String[] args) {
		boot();
	}
	
	public static void boot() {
		String employeeName = StdInputRead.stringInput();
		BankEmployeeVerifyAppointmentsTransaction.verifyAppointment(employeeName);
	}
}
