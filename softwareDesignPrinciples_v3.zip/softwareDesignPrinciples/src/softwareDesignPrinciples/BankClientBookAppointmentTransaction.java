package softwareDesignPrinciples;

import java.util.Date;

public class BankClientBookAppointmentTransaction {
	
	public static void createCandidateAppointment(Date date, String time) {
		CandidateAppointment appointment = new CandidateAppointment(date, time);
		boolean check = ScheduledAppointment.checkAvailability(appointment);
		if(check == true) {
			BankEmployeeVerifyAppointmentsTransaction.addCandidateAppointment(appointment);
		}
	}
}
