package softwareDesignPrinciples;

import java.util.ArrayList;

public class BankClientLoginTransaction {
	
	public static ArrayList<BankClientCredentials> Credentials = new ArrayList<BankClientCredentials>();

	public static BankClientProfileConcrete login(String username, String password) {
		BankClientProfileConcrete profile = null;
		for(BankClientCredentials cred: Credentials) {
			if(cred.getUsername().equals(username) && cred.getPassword().equals(password)) {
				profile = cred.getProfile();
			}
		}
		return profile;
	}
}
