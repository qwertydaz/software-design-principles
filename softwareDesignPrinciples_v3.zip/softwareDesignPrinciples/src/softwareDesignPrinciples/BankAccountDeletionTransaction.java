package softwareDesignPrinciples;

public class BankAccountDeletionTransaction {
	
	public static void deleteAccount(BankClientProfileConcrete profile) {
		SavingsAccount savingsAccount = profile.getSavingsAccount();
		PrimaryAccount primaryAccount = profile.getPrimaryAccount();
		
		savingsAccount.accountBalance = 0;
		savingsAccount.accountNumber = 0;
		savingsAccount.accountVerified = false;
		
		primaryAccount.accountBalance = 0;
		primaryAccount.accountNumber = 0;
		savingsAccount.accountVerified = false;
	}
}
